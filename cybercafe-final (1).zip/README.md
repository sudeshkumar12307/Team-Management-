# Cyber Cafe Manager: Start-to-finish guide

Free app for managing a cyber cafe team. Private service-centre software: not a government app, not a CSC. Applications are submitted through the official portals.

Roles: Admin, Super Distributor, Distributor (both pay a fee set by admin), Retailer (cafe owner, FREE), Operator (created by the retailer).

---
## PART A: Firebase (free plan)
1. Open console.firebase.google.com, log in, tap **Create a project**. Name it (e.g. cybercafe-manager). Turn Google Analytics off. Create.
2. **Build > Authentication > Get started > Email/Password > Enable > Save.**
3. **Build > Firestore Database > Create database > Production mode > choose region (asia-south1) > Enable.**
4. **Build > Hosting > Get started** (just tap through).
5. Gear icon > **Project settings > Your apps > Web (</>)**. Nickname: Cyber Cafe Manager. Leave Hosting box unticked. Register. Keep the `firebaseConfig` values open: you need them in Part B.
6. **Firestore > Rules** tab: delete everything, paste the contents of `firestore.rules`, tap **Publish**.

## PART B: GitHub
7. github.com > **+ > New repository**. Name `cybercafe-app`, Public, Create.
8. Extract the zip on your device. In the repo tap **uploading an existing file**. Upload `README.md`, `firebase.json`, `firestore.rules`, `firestore.indexes.json` and the whole `public` folder. Commit.
9. Dot files are hidden on many devices, so create them by typing. Use **Add file > Create new file** for each, paste the contents of the plain copy I sent, commit:
   - name `.firebaserc` (paste `firebaserc.txt`; replace YOUR-FIREBASE-PROJECT-ID with your real project ID, shown in Firebase Project settings)
   - name `.github/workflows/deploy.yml` (paste `deploy.yml`)
   - name `.github/workflows/build-apk.yml` (paste `build-apk.yml`)
10. Open `public/js/firebase-config.js` > pencil icon. Replace the PASTE_ values with your `firebaseConfig` from step 5. Commit.

## PART C: Put the website online
11. Firebase > Project settings > **Service accounts > Generate new private key**. A .json file downloads. Open it and copy everything.
12. GitHub repo > **Settings > Secrets and variables > Actions > New repository secret**. Add:
    - `FIREBASE_SERVICE_ACCOUNT` = the whole json text
    - `FIREBASE_PROJECT_ID` = your project ID
    - `APP_URL` = `https://YOUR-PROJECT-ID.web.app`
13. Open the **Actions** tab. Open **Deploy to Firebase Hosting** > **Run workflow** (or make any small commit). Wait for the green tick.
14. Open `https://YOUR-PROJECT-ID.web.app`. The login screen should appear.

## PART D: Make yourself admin
15. On the website register as **Retailer** with your email.
16. Firebase > Firestore Database > `users` > open your document > change `role` from `retailer` to `admin` > Update.
17. Log out and in. Open **Settings**: set Distributor fee, Super Distributor fee, your UPI ID and name. Save.
    (Create a second email as Retailer to test as a cafe owner.)

## PART E: Install on phone
- Quick: open the website in Chrome > three dots > **Install app**.
- APK file: GitHub **Actions > Build Android APK > Run workflow**. After it finishes, open the run, download **CyberCafeManager-apk** (zip), extract, install `app-debug.apk` (allow unknown sources).

## Using it
- Retailer: Shop tab: shop name, UPI ID, incentive rules. Services tab: tap "Add common services", switch on/off. Team tab: add operators. Orders tab: add customer orders, show QR, mark Paid.
- Operators log in with the email/password you created and see their own orders, attendance and extra income.
- Distributors share their referral link; admin approves their fee payment under Home.
- Always confirm the money in your bank before marking Paid.
